class TCODLIB_GUI_API HBox : public VBox {
public :
	HBox(int x, int y, int padding);
	void computeSize();
};

