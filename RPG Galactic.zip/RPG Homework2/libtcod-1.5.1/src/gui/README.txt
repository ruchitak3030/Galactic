Those classes are a C++ widget toolkit built on top of libtcod.
